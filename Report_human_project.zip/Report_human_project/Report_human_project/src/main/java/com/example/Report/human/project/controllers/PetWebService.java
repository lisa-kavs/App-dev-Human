package com.example.Report.human.project.controllers;

import com.example.Report.human.project.daos.dtos.newPet;
import com.example.Report.human.project.entities.House;
import com.example.Report.human.project.entities.Pet;
import com.example.Report.human.project.services.HouseService;
import com.example.Report.human.project.services.PetService;
import com.example.Report.human.project.services.exceptions.BadDataException;
import com.example.Report.human.project.services.exceptions.NotFoundException;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/myapi/pets")
public class PetWebService {
    private PetService petService;
    private HouseService houseService;

    @Autowired
    public PetWebService(PetService petService, HouseService houseService) {
        this.petService = petService;
        this.houseService = houseService;
    }

//    Get all the pets
@GetMapping({"/", ""})
public List<Pet> getAllPets() {
    return petService.getAllPets();
}

//    Get a pet
@GetMapping({"/{id}"})
public Pet getPetById(@PathVariable("id") int id) throws NotFoundException {
    return petService.getPetById(id);
}

//    Delete a pet
@DeleteMapping({"/{id}"})
public void deletePetById(@PathVariable("id") int id) throws NotFoundException {
    petService.deleteByPetId(id);
}

//    Create a new pet (POST)
@PostMapping({"/"})
@ResponseStatus(HttpStatus.CREATED)
public void addPet(@RequestBody @Valid newPet NewPet) throws BadDataException, NotFoundException {
    House house = null;
//    if (NewPet.name() != null) {
////        house = houseService.getHouseById(NewPet.name());
//    }
    Pet pet = new Pet(NewPet.name(), NewPet.animalType(), NewPet.breed());
    petService.createPet(pet);
}

//    Change a pet's name (PATCH)
@PatchMapping({"/{id}/{newName}"})
public void updatePetName(@PathVariable int id, @PathVariable String newName) throws NotFoundException {
    petService.updatePetById(id, newName);
}





}
