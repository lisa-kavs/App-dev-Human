package com.example.Report.human.project;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Slf4j
public class Aspects {


    @AfterReturning(value = "execution(* findAll(..))", returning = "pets")
    public void afterReturningFromFindAll(JoinPoint joinPoint, Object pets) {
        log.info("Returning from {} with {}", joinPoint.getSignature().getName(),
                pets);
    }

}
