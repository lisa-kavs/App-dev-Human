package com.example.Report.human.project.daos.dtos;

public record Animal(String name, String animalType, String breed) {
}
