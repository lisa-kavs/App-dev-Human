package com.example.Report.human.project.daos.dtos;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record newHouse(
        int id,
        @NotEmpty @NotNull String eircode,
        int no_occupants,
        int max_occupants,
        int owner_occupied
) {
}
