package com.example.Report.human.project.services;


import com.example.Report.human.project.entities.House;
import com.example.Report.human.project.entities.Pet;
import com.example.Report.human.project.services.exceptions.BadDataException;
import com.example.Report.human.project.services.exceptions.NotFoundException;

import java.util.List;

public interface HouseService {
    House getHouseById(int id) throws NotFoundException;
    List<House> getAllHouses();
    void deleteByHouseId(int id) throws NotFoundException;
    House createHouse(House house) throws BadDataException, NotFoundException;
}
