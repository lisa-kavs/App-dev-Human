package com.example.Report.human.project.daos;

import com.example.Report.human.project.daos.dtos.Animal;
import com.example.Report.human.project.entities.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface PetRepository extends JpaRepository<Pet, Integer> {
    int deleteByPetId(Integer id);
    Optional<Pet> findById(int id);
    List<Pet> findPetByAnimalType(String animalType);
    List<Pet> findPetByBreed(String breed);


    Pet save(Pet pet);

    @Modifying
    @Transactional
    @Query(value = "UPDATE pets SET name=:newName WHERE pet_id=:id",
            nativeQuery = true)
    int updatePetsById(@Param("id") int id, @Param("newName") String newName);

    @Transactional
    @Modifying
    int deleteAllPetsByName(String name);

    @Query("SELECT new com.example.Report.human.project.daos.dtos.Animal(p.name, p.animal_type, p.breed ) FROM Pet p")
    List<Animal> findAllByNameBreed();





}
