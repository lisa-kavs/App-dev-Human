package com.example.Report.human.project;

import com.example.Report.human.project.daos.HouseRepository;
import com.example.Report.human.project.daos.PetRepository;
import org.springframework.boot.CommandLineRunner;

public class DataLoader implements CommandLineRunner {

    private HouseRepository houseRepository;
    private PetRepository petRepository;
    @Override
    public void run(String... args) throws Exception {

    }
}
