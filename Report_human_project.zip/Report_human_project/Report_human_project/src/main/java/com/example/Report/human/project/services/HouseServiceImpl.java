package com.example.Report.human.project.services;

import com.example.Report.human.project.daos.HouseRepository;
import com.example.Report.human.project.daos.PetRepository;
import com.example.Report.human.project.entities.House;
import com.example.Report.human.project.services.exceptions.NotFoundException;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Data
@AllArgsConstructor
public class HouseServiceImpl implements HouseService {
    private final HouseRepository houseRepository;
    private final PetRepository petRepository;

    @Override
    public House getHouseById(int id) {
        return houseRepository.findById(id).orElseThrow(
                () -> new NotFoundException("House not found ID: " + id)
        );
    }

    @Override
    public List<House> getAllHouses() {
        return houseRepository.findAll();
    }

    @Override
    public void deleteByHouseId(int id) throws NotFoundException {
        int rowsAffected = houseRepository.deleteByHouseId(id);
        if (rowsAffected != 1) {
            throw new NotFoundException("House not found ID: " + id);
        }
    }

    @Override
    public House createHouse(House house) {
        return houseRepository.save(house);
    }


}
