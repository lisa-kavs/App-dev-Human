package com.example.Report.human.project.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "pets")
@AllArgsConstructor
@NoArgsConstructor
public class Pet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int petId;
    private String name;
    private String animal_type;
    private String breed;
    private int age;

    @ManyToOne
    @JoinColumn(name="eircode")
    @JsonManagedReference  // serialise data into json - the parent in the relationship
    House house;

    public Pet(String name, String animal_type, String breed) {
        this.name = name;
        this.animal_type = animal_type;
        this.breed = breed;

    }


}
