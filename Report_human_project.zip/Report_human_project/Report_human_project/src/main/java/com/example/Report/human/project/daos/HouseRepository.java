package com.example.Report.human.project.daos;

import com.example.Report.human.project.entities.House;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HouseRepository extends JpaRepository<House, Integer> {
    int deleteByHouseId(Integer houseId);
}
