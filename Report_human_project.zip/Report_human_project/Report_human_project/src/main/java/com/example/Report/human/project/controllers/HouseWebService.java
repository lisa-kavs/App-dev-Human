package com.example.Report.human.project.controllers;

import com.example.Report.human.project.entities.House;
import com.example.Report.human.project.services.HouseService;
import com.example.Report.human.project.services.PetService;
import com.example.Report.human.project.services.exceptions.NotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/myapi/houses")
public class HouseWebService {
    private final HouseService houseService;
    private final PetService petService;

    @Autowired
    public HouseWebService(HouseService houseService, PetService petService) {
        this.houseService = houseService;
        this.petService = petService;
    }


    //    Get all the households
//    Get households with no pets
//    Get a household
//    Delete a household
//    Create a new household (POST)
    @GetMapping({"/{id}"})
    public House getHouseById(@PathVariable("id") int id) throws NotFoundException {
        return houseService.getHouseById(id);
    }
}

