package com.example.Report.human.project.services;

import com.example.Report.human.project.daos.dtos.Animal;
import com.example.Report.human.project.entities.Pet;
import com.example.Report.human.project.services.exceptions.BadDataException;
import com.example.Report.human.project.services.exceptions.NotFoundException;

import java.util.List;


public interface PetService {
    Pet createPet(Pet pet) throws BadDataException, NotFoundException;

    List<Pet> getAllPets();

    Pet getPetById(int id) throws NotFoundException;

    Pet updatePetById(int id, String name) throws BadDataException, NotFoundException;

    void deleteByPetId(int id) throws NotFoundException;

    void deleteAllPetsByName(String name) throws NotFoundException;

    List<Pet> findPetByAnimalType(String animalType) throws NotFoundException;

    Pet findPetByBreed(String breed) throws NotFoundException;

    List<Animal> findPetByNames_Breed(String name, String breed) throws NotFoundException;

    Pet getPetStatistics(int averageAge , int oldestAge) throws NotFoundException;





}
