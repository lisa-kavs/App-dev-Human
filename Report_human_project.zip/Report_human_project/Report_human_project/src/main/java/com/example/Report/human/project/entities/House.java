package com.example.Report.human.project.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Entity
@Table(name = "household")
@AllArgsConstructor
@NoArgsConstructor
public class House {
    @Id
    private int id;
    private String eircode;
    private int no_occupants;
    private int max_occupants;
    private int owner_occupied;

    @OneToMany
    @JsonBackReference
    private List<Pet> pets;


}
