package com.example.Report.human.project.controllers;

import com.example.Report.human.project.daos.dtos.newHouse;
import com.example.Report.human.project.entities.House;
import com.example.Report.human.project.entities.Pet;
import com.example.Report.human.project.services.HouseService;
import com.example.Report.human.project.services.PetService;
import com.example.Report.human.project.services.exceptions.BadDataException;
import com.example.Report.human.project.services.exceptions.NotFoundException;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;

import java.util.List;


@Controller
@AllArgsConstructor
public class graphQL {
    private PetService petService;
    private HouseService houseService;

//    Queries
    @QueryMapping
    House getHouseById(@Argument int id) {
        return houseService.getHouseById(id);
    }
    @QueryMapping
    List<House> findAllHouses() {
        return houseService.getAllHouses();
    }

    @QueryMapping
    List<Pet> findPetByAnimalType(@Argument String animalType) {
        return petService.findPetByAnimalType(animalType);
    }

    @QueryMapping
    Pet getPetById(@Argument int id) {
        return petService.getPetById(id);
    }

    @QueryMapping
    Pet getPetStatistics(@Argument int average_age, @Argument int oldest_age) {
        return petService.getPetStatistics(average_age, oldest_age);
    }


//    Mutations

    @MutationMapping
    void deleteHouseById(@Argument int id) {
        houseService.deleteByHouseId(id);
    }


    @MutationMapping
    void deletePetById(@Argument int id) {
        petService.deleteByPetId(id);
    }


    @Secured(value = "ROLE_ADMIN")
    @MutationMapping
    House createHouse(@Valid @Argument("house") newHouse Newhouse) throws BadDataException, NotFoundException {
//        House house = new House(Newhouse.id(), Newhouse.max_occupants(),Newhouse.eircode(),Newhouse.no_occupants(),Newhouse.owner_occupied())
//        return houseService.createHouse(house);
        return null;

    }





}
