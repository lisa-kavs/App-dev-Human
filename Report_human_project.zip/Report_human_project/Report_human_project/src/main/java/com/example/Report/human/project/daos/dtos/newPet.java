package com.example.Report.human.project.daos.dtos;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record newPet(

        @NotEmpty @NotNull String name,
         String breed,
         @NotEmpty @NotNull String animalType
         ) {
}
