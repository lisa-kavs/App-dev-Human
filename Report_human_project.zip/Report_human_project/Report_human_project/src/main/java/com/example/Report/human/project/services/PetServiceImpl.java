package com.example.Report.human.project.services;

import com.example.Report.human.project.daos.HouseRepository;
import com.example.Report.human.project.daos.PetRepository;
import com.example.Report.human.project.daos.dtos.Animal;
import com.example.Report.human.project.entities.Pet;
import com.example.Report.human.project.services.exceptions.BadDataException;
import com.example.Report.human.project.services.exceptions.NotFoundException;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Data
@AllArgsConstructor
public class PetServiceImpl implements PetService{
    private PetRepository petRepository;
    private HouseRepository houseRepository;

    @Transactional
    @Override
    public Pet createPet(Pet pet) throws BadDataException {
        return petRepository.save(pet);

    }

    @Override
    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    @Override
    public Pet getPetById(int id) throws NotFoundException {
        return petRepository.findById(id).orElseThrow(
                () -> new NotFoundException("Pet not found ID: " + id));
    }

    @Transactional
    @Override
    public Pet updatePetById(int id, String name) throws BadDataException, NotFoundException {
        int petRowAffected = petRepository.updatePetsById(id, name);
        if(petRowAffected !=1)
            throw new NotFoundException("Pet not found ID: " + id);
        return getPetById(id);

    }

    @Transactional
    @Override
    public void deleteByPetId(int id) throws NotFoundException {
        int petRowAffected = petRepository.deleteByPetId(id);
        if (petRowAffected != 1) {
            throw new NotFoundException("Pet not found ID: " + id);
        }

    }

    @Transactional
    @Override
    public void deleteAllPetsByName(String name) throws NotFoundException {
        if(petRepository.deleteAllPetsByName(name.toUpperCase()) == 0)
            throw new NotFoundException("Pet not found Name: " + name);

    }

    @Override
    public List<Pet> findPetByAnimalType(String animalType) throws NotFoundException {
        return petRepository.findPetByAnimalType(animalType);
    }

    @Override
    public Pet findPetByBreed(String breed) throws NotFoundException {
        return null;
    }

    @Override
    public List<Animal> findPetByNames_Breed(String name, String breed) throws NotFoundException {
        return petRepository.findAllByNameBreed();
    }

    @Override
    public Pet getPetStatistics(int averageAge, int oldestAge) throws NotFoundException {
        return null;
    }

}
