package com.example.Report.human.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportHumanProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
